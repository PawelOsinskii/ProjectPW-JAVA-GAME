package pl.edu.pw.fizyka.pojava.JankowskiOsinski.people;

public interface Stats {

	int HP_START = 100;
	int MANA_START = 100;
	int SHIELDING_START = 10;
	int MAGIC_LEVEL_START = 1;
	int ATTACK_LEVEL_START = 1;
	int GOLD_START = 50;
	static final int WALK_SPEED = 2;
	
}
