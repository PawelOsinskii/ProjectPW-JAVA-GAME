package pl.edu.pw.fizyka.pojava.JankowskiOsinski;

import com.badlogic.gdx.scenes.scene2d.Stage;

public class Shop {

	// w innym projecie próbuję zrobić, trzeba zaznaczyć Tools przy generowaniu
	// projektu
	Stage stage;
	
}
