<?xml version="1.0" encoding="UTF-8"?>
<tileset name="goblin_new" tilewidth="32" tileheight="32" tilecount="1" columns="1">
 <image source="goblin_new.png" width="32" height="32"/>
 <tile id="0">
  <objectgroup draworder="index">
   <object id="3" x="1.33333" y="1.33333" width="31.3333" height="32.6667"/>
  </objectgroup>
 </tile>
</tileset>
