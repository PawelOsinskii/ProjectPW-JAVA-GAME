<?xml version="1.0" encoding="UTF-8"?>
<tileset name="blizzard_demon" tilewidth="32" tileheight="32" tilecount="1" columns="1">
 <image source="blizzard_demon.png" width="32" height="32"/>
 <tile id="0">
  <objectgroup draworder="index">
   <object id="1" x="0.666667" y="1.33333" width="30.6667" height="30"/>
  </objectgroup>
 </tile>
</tileset>
