<?xml version="1.0" encoding="UTF-8"?>
<tileset name="terrain_atlas" tilewidth="32" tileheight="32" tilecount="1024" columns="32">
 <image source="terrain_atlas.png" width="1024" height="1024"/>
</tileset>
