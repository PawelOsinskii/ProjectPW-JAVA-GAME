<?xml version="1.0" encoding="UTF-8"?>
<tileset name="LmP25n" tilewidth="32" tileheight="32" tilecount="190" columns="19">
 <image source="LmP25n.png" width="624" height="336"/>
</tileset>
